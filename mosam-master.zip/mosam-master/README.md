# Welcome to Mosam WebApp👋

### Screenshot

![1](https://user-images.githubusercontent.com/66557474/214074145-fd5ea534-83e6-447e-a91c-5d7f559f3889.png)
![2](https://user-images.githubusercontent.com/66557474/214074220-9ab9650e-bb17-4b06-b622-b15e74bb8f99.png)

### Introduction

An interactive Web application which shows the weather of any city or country in real time.<br>

->fronted created using HTML, CSS and Javascript.<br>
->apikey is used to access weather - given via OpenWeatherApp.<br>
->used unsplash to change the background image as per the searched location.<br>

### Check out the Mosam right now!

• Project Link: https://oyesaurabh.github.io/mosam/<br>
• Source Code: https://github.com/oyeSAURABH/mosam
